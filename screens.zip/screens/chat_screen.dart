// import 'dart:io';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/////////////////////////////////
final _firstor = FirebaseFirestore.instance;
late User sinedInUser; //this will give as Email
final messageTextControlr = TextEditingController();

/////////////////////
class ChatScreen extends StatefulWidget {
  static const screenRoute = 'chat_screen';
  const ChatScreen({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  //////VirableToPrentEmailNewUserAndSendMesges//////
  final _auth = FirebaseAuth.instance;

  ///////////savemesseges////////
  String? messageText; //this will give as messg
  // GlobalKey<FormState> haithamR = GlobalKey<FormState>();
  /////////////////
  @override
  void initState() {
    super.initState();

    controller = TextEditingController();

    controller.addListener(() async {
      final isButtonActive = controller.text.isNotEmpty;
      setState(() => this.isButtonActive = isButtonActive);
      if (haithamR.currentState!.validate()) {
        // ScaffoldMessenger.of(context).showSnackBar(
        //   const SnackBar(
        //     content: Text('Processing Data'),
        //   ),
        // );
      }
      //////////DeletMessages//////////
      messageTextControlr.clear();
      /////////////////////////////////
      _firstor.collection('messages').add(
        {
          'text': messageText,
          'sender': sinedInUser.email,
          'time': FieldValue.serverTimestamp(),
        },
      );
    });
    super.initState();
    getCurrentUser();
  }

  ////ifStatmentHappendWeHaveUserLoginIfNoUserif=0////
  void getCurrentUser() {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        sinedInUser = user;
        // ignore: avoid_print
        print(sinedInUser.email);
      }
    } catch (e) {
      // ignore: avoid_print
      print(e);
    }
  }

  ////////////GetMessagesMethod////////////
  // void getMessages() async {
  //   final messages = await _firstor.collection('messages').get();
  //   for (var message in messages.docs) {
  //     // ignore: avoid_print
  //     print(message.data());
  //   }
  // }

  ////MessagesStreamsFuncationUsedToSeeNewMessagesWithoutClickButton/////
  void messagesStreams() async {
    await for (var snapshot in _firstor.collection('messages').snapshots()) {
      for (var message in snapshot.docs) {
        // ignore: avoid_print
        print(message.data());
      }
    }
  }

  GlobalKey<FormState> haithamR = GlobalKey<FormState>();
  /////////////////isButtonActive///////////
  bool isButtonActive = true;
  late TextEditingController controller;
  @override
  // void initState() {
  // super.initState();

  // controller = TextEditingController();

  // controller.addListener(() async {
  //   final isButtonActive = controller.text.isNotEmpty;
  //   setState(() => this.isButtonActive = isButtonActive);
  //   if (haithamR.currentState!.validate()) {
  //     // ScaffoldMessenger.of(context).showSnackBar(
  //     //   const SnackBar(
  //     //     content: Text('Processing Data'),
  //     //   ),
  //     // );
  //   }
  //   //////////DeletMessages//////////
  //   messageTextControlr.clear();
  //   /////////////////////////////////
  //   _firstor.collection('messages').add(
  //     {
  //       'text': messageText,
  //       'sender': sinedInUser.email,
  //       'time': FieldValue.serverTimestamp(),
  //     },
  //   );
  // });
  // }

  @override
  void dispose() {
    controller.dispose();

    super.dispose();
  }

  ///////////End///////////////
  // bool isFieldEmpty = true;
  //////////////////////////////////////////
  @override
  Widget build(BuildContext contxt) {
    return DefaultTabController(
      // animationDuration: kTabScrollDuration,
      initialIndex: 0,
      length: 3,
      child: Scaffold(
        endDrawer: Drawer(
          elevation: 16.0,
          child: ListView(
            addAutomaticKeepAlives: true,
            addSemanticIndexes: true,
            shrinkWrap: true,
            children: [
              //////////////LogoutMesges///////////////////////
              ListTile(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (x) {
                      return AlertDialog(
                        backgroundColor: const Color.fromARGB(255, 227, 89, 80),
                        alignment: Alignment.center,
                        title: const Text("Logout"),
                        icon: const Icon(Icons.warning),
                        content:
                            const Text("Are you sour you want to Logout! "),
                        actions: [
                          IconButton(
                            onPressed: () {
                              _auth.signOut();
                              Navigator.pop(context);
                              // Navigator.pushNamed(
                              //     context, WelcomeScreen.screenRoute);
                            },
                            icon: const Icon(
                              Icons.check_box,
                            ),
                          ),
                          const Text("yes")
                        ],
                        actionsAlignment: MainAxisAlignment.end,
                      );
                    },
                  );
                },
                leading: const Icon(Icons.logout),
                title: const Text("Logout"),
              ),
              /////////////////////End////////////////////////
              ///////////////DevelopersPage//////////////////
              ListTile(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (x) {
                      return Scaffold(
                        appBar: AppBar(
                          actions: [
                            IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(Icons.exit_to_app),
                            )
                          ],
                          title: const Text(
                            'Developers Page',
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          // leadingWidth: 110,
                          automaticallyImplyLeading: true,
                          backgroundColor: Colors.yellow[900],
                          leading: Row(
                            children: [
                              Image.asset('images/logo.png', height: 60),
                            ],
                          ),
                        ),
                        body: Container(
                          alignment: Alignment.center,
                          child: Stack(
                            children: [getCard(), getImag()],
                          ),
                        ),
                      );
                    },
                  );
                },
                leading: const Icon(Icons.developer_mode),
                title: const Text("Developers"),
              ),
              ////////////////////End/////////////////////////////
              ////////////Share///////////////////////////////////
              ListTile(
                onTap: () {},
                leading: const Icon(Icons.share),
                title: const Text("Share"),
              ),
              ////////////////////End/////////////////////////
              ////////////////////Facebook///////////////////
              ListTile(
                onTap: () {},
                leading: const Icon(Icons.facebook),
                title: const Text("Facebook"),
              ),
              ////////////////////End/////////////////////////
              /////////////////StartToSeeMessages/////////////////////
              ListTile(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (x) {
                      return IconButton(
                        onPressed: () {
                          messagesStreams();
                        },
                        icon: const Icon(Icons.chat),
                      );
                    },
                  );
                },
                leading: const Icon(Icons.chat_outlined),
                title: const Text("See Preceded Messages"),
              ),
              /////////////////EndSeePrUsersMessages/////////////////////
            ],
          ),
        ),
        appBar: AppBar(
          centerTitle: true,
          shadowColor: Colors.orange,
          automaticallyImplyLeading: false,
          backgroundColor: Colors.blue[800]!,
          excludeHeaderSemantics: true,
          toolbarHeight: 70,
          title: Row(
            children: [
              Image.asset('images/logo.png', height: 46),
              const SizedBox(width: 5),
              const Text('SecureCh@t')
            ],
          ),
        ),
        // body
        body: Form(
          key: haithamR,
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const MessageStreamBuilder(),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: controller,
                        // autofocus: true,
                        validator: ((value) {
                          if (value == null || value.isEmpty) {
                            return 'Plesce Write your message!!!';
                          }
                          return null;
                        }),
                        textAlign: TextAlign.center,
                        // controller: messageTextControlr,
                        onChanged: (value) {
                          messageText = value;
                        },
                        decoration: InputDecoration(
                          filled: true,
                          label: const Text("messaging"),
                          hintText: 'Write your message here...',
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 30,
                            horizontal: 30,
                          ),
                          border: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(10),
                            ),
                          ),
                          enabledBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.orange,
                              width: 1,
                            ),
                            borderRadius: BorderRadius.all(
                              Radius.circular(10),
                            ),
                          ),
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.blue,
                              width: 2,
                            ),
                            borderRadius: BorderRadius.all(
                              Radius.circular(8),
                            ),
                          ),
                          suffixIcon: IconButton(
                            onPressed: isButtonActive
                                ? () {
                                    setState(() => isButtonActive = false);
                                    controller.clear();
                                  }
                                : null,
                            // onPressed: () {
                            //   if (haithamR.currentState!.validate()) {
                            //     // ScaffoldMessenger.of(context).showSnackBar(
                            //     //   const SnackBar(
                            //     //     content: Text('Processing Data'),
                            //     //   ),
                            //     // );
                            //   }
                            //   //////////DeletMessages//////////
                            //   messageTextControlr.clear();
                            //   /////////////////////////////////
                            //   _firstor.collection('messages').add(
                            //     {
                            //       'text': messageText,
                            //       'sender': sinedInUser.email,
                            //       'time': FieldValue.serverTimestamp(),
                            //     },
                            //   );
                            // },
                            /////////////
                            // onLongPress: () {
                            //   showsnackpar(context);
                            //   messageTextControlr.clear(); ////temp
                            // },
                            icon: Icon(
                              Icons.send,
                              color: Colors.blue[800]!,
                            ),
                          ),
                        ),
                      ),
                    ),
                    ////
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/////////////////////FunctionCansalSend///////////////////////
showsnackpar(BuildContext context) {
  return ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      action: SnackBarAction(
        label: "Yes",
        onPressed: () {
          messageTextControlr.clear();
        },
      ),
      backgroundColor: const Color.fromARGB(255, 255, 152, 0),
      content: const Text("Do you want to Cancel !"),
    ),
  );
}
///////////////////////End//////////////////////////////

////////////////////////DevelopersPageGetCarde////////////////////////////
getCard() {
  return Container(
    margin: const EdgeInsets.all(20),
    width: 350,
    height: 160,
    decoration: BoxDecoration(
        color: Colors.yellow[900], borderRadius: BorderRadius.circular(10)),
    child: Column(
      children: [
        const Text(
          "Eng: Haitham Al_Shami",
          style: TextStyle(
            fontFamily: "DancingScript",
            fontSize: 25,
            color: Color.fromRGBO(7, 3, 3, 1),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Text("Gmail: haithamalshami81@gmail.com"),
            Icon(Icons.email),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Text("Phone: +967774692982"),
            Icon(Icons.phone),
          ],
        ),
      ],
    ),
  );
}

//////////////////////DevelopersPageGetImag////////////////////////
getImag() {
  return Container(
    margin: const EdgeInsets.all(95),
    width: 900,
    height: 140,
    decoration: BoxDecoration(
      image: const DecorationImage(
          image: AssetImage("images/haitham.png"), fit: BoxFit.fill),
      border: Border.all(color: const Color(0xFF000000), width: 2),
      borderRadius: BorderRadius.circular(100),
    ),
  );
}

//////////////////EndGetImage///////////////////
//////////////////MessageStreamBuilder//////////
class MessageStreamBuilder extends StatelessWidget {
  const MessageStreamBuilder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _firstor.collection('messages').orderBy('time').snapshots(),
      builder: (context, snapshot) {
        /////ListContextsAlMessages//////
        List<MessageLine> messageWidgets = [];
        if (!snapshot.hasData) {
          return const Center(
            child: CircularProgressIndicator(
              backgroundColor: Colors.blue,
            ),
          );
        }
        final messages = snapshot.data!.docs.reversed;
        for (var message in messages) {
          final messageText = message.get('text');
          final messageSender = message.get('sender');
          final currentUser = sinedInUser.email;
          // if (currentUser == messageSender) {
          //   //The Code of the Message from sinedInUser
          // }
          final messageWidget = MessageLine(
            sender: messageSender,
            text: messageText,
            isMe: currentUser == messageSender,
          );
          messageWidgets.add(messageWidget);
        }
        return Expanded(
          child: ListView(
            reverse: true,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            children: messageWidgets,
          ),
        );
      },
    );
  }
}

////////////////EndMessageStreamBuilder/////////////

class MessageLine extends StatelessWidget {
  const MessageLine({this.text, this.sender, required this.isMe, Key? key})
      : super(key: key);
  final String? sender;
  final String? text;
  final bool isMe;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        crossAxisAlignment:
            isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Text(
            '$sender',
            style: TextStyle(fontSize: 12, color: Colors.yellow[900]),
          ),
          Material(
            elevation: 5,
            borderRadius: isMe
                ? const BorderRadius.only(
                    topLeft: Radius.circular(30),
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  )
                : const BorderRadius.only(
                    topRight: Radius.circular(30),
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
            color: isMe ? Colors.blue[800] : Colors.white,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Text(
                '$text',
                style: TextStyle(
                    fontSize: 15, color: isMe ? Colors.white : Colors.black45),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
