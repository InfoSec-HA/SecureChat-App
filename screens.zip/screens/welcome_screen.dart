import 'dart:math';

import 'package:flutter/material.dart';
import 'package:scurechat11/screens/registration_screen.dart';
import 'package:scurechat11/screens/signin_screen.dart';
import 'package:scurechat11/widgets/my_button.dart';

class WelcomeScreen extends StatefulWidget {
  static const String screenRoute = 'welcome_screen';
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  Widget build(BuildContext context) {
    var myButton = MyButton(
      color: Colors.yellow[900]!,
      title: 'Sign in',
      onPressed: () {
        Navigator.pushNamed(context, SignInScreen.screenRoute);
      },
    );
    var myButton2 = MyButton(
      color: Colors.blue[800]!,
      title: 'Register',
      onPressed: () {
        Navigator.pushNamed(context, RegistrationScreen.screenRoute);
      },
    );
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        shadowColor: Colors.orange,
        automaticallyImplyLeading: false,
        backgroundColor: Colors.blue[800]!,
        excludeHeaderSemantics: true,
        toolbarHeight: 70,
        leadingWidth: 110,
        actions: [
          IconButton(
            onPressed: () {
              // Navigator.pushNamed(context, RegistrationScreen.screenRoute);
            },
            icon: const Icon(Icons.chat),
          ),
        ],
        title: const Text(
          "Welcome to SecureCh@t",
          style: TextStyle(
            // color: fontColors,
            fontSize: 20,
            wordSpacing: sqrt1_2,
            fontWeight: FontWeight.w900,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Column(
              children: [
                SizedBox(
                  height: 250,
                  child: Image.asset('images/logo.png'),
                ),
                const Text(
                  'SecureCh@t',
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.w900,
                    color: Color(0xff2e386b),
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
            const SizedBox(height: 50),
            myButton,
            myButton2
          ],
        ),
      ),
    );
  }
}
