// import 'dart:html';

// import 'dart:ui';

import 'package:flutter/material.dart';
// import 'package:scurechat11/widgets/my_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:scurechat11/screens/chat_screen.dart';
// import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

// import 'package:scurechat/screens/chat_screen.dart';
// import 'package:firebase_auth/firebase_auth.dart';

class SignInScreen extends StatefulWidget {
  static const screenRoute = 'signin_screen';
  const SignInScreen({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _SignInScreenState createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final _auth = FirebaseAuth.instance;
  bool showSpinner = false;
  late String email;
  late String password;
  TextEditingController name = TextEditingController();
  TextEditingController pass = TextEditingController();
  bool isvis = true;
  GlobalKey<FormState> haithamR = GlobalKey<FormState>();
  /////////////////isButtonActive///////////
  bool isButtonActive = true;
  late TextEditingController controller;

  @override
  void initState() {
    super.initState();

    controller = TextEditingController();

    controller.addListener(() async {
      final isButtonActive = controller.text.isNotEmpty;
      setState(() => this.isButtonActive = isButtonActive);
      if (haithamR.currentState!.validate()) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Processing Data'),
          ),
        );
      }
      try {
        final user =
            _auth.signInWithEmailAndPassword(email: email, password: password);
        // ignore: unrelated_type_equality_checks
        if (user != email) {
          Navigator.pushNamed(context, ChatScreen.screenRoute);
        }
      } catch (e) {
        // ignore: avoid_print
        print(e);
      }
    });
  }

  @override
  void dispose() {
    controller.dispose();

    super.dispose();
  }

///////////End///////////////
  @override
  Widget build(BuildContext context) {
    // const fontColors = Color.fromARGB(255, 30, 11, 103);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        shadowColor: Colors.orange,
        actions: [
          IconButton(
            onPressed: () {
              // Navigator.of(context).pushNamed("registration_screen");
              Navigator.pop(context);
            },
            icon: const Icon(Icons.login),
          )
        ],
        title: const Text(
          'SecureCh@t  Signin',
          style: TextStyle(
            fontWeight: FontWeight.w900,
          ),
        ),
        // leadingWidth: 110,
        automaticallyImplyLeading: true,
        backgroundColor: Colors.blue[800]!,
        leading: Row(
          children: [
            Image.asset('images/logo.png', height: 60),
          ],
        ),
        // centerTitle: true,
      ),
      body: Form(
        key: haithamR,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                // controller: controller,
                validator: ((value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please Enter your Email Address';
                    // ignore: unrelated_type_equality_checks
                  } else if (value != TextInputType.emailAddress) {
                    return 'The Email Address is Wrong!!!';
                  }
                  return null;
                }),
                controller: name,
                enableInteractiveSelection: false,
                ///////@//////
                keyboardType: TextInputType.emailAddress,
                ///////@//////
                textAlign: TextAlign.center,
                onChanged: (value) {
                  email = value;
                },
                decoration: const InputDecoration(
                  filled: true,
                  icon: Icon(Icons.email),
                  label: Text("Emial"),
                  hintText: 'Enter your Email',
                  contentPadding: EdgeInsets.symmetric(
                    vertical: 10,
                    horizontal: 20,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.orange,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.blue,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: controller,
                validator: ((value) {
                  if (value == null || value.isEmpty) {
                    return 'Please Enter your Password';
                  } else if (value.trim().isEmpty || value.trim().length < 6) {
                    return 'The Password should be more than 6 characters!!!';
                  }
                  return null;
                }),
                obscureText: isvis,
                textAlign: TextAlign.center,
                onChanged: (value) {
                  password = value;
                },
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(
                        () {
                          isvis = !isvis;
                        },
                      );
                    },
                    icon: isvis
                        ? const Icon(
                            Icons.visibility,
                            size: 20,
                          )
                        : const Icon(
                            Icons.visibility_off,
                            size: 20,
                          ),
                  ),
                  icon: const Icon(Icons.lock),
                  label: const Text("password"),
                  filled: true,
                  ////////////////////////////
                  hintText: 'Enter your password',
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 10,
                    horizontal: 20,
                  ),
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  enabledBorder: const OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.orange,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.blue,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                // ignore: deprecated_member_use
                style: ElevatedButton.styleFrom(onSurface: Colors.blue),
                onPressed: isButtonActive
                    ? () {
                        setState(() => isButtonActive = false);
                        controller.clear();
                      }
                    : null,
                //  onPressed: () async {
                //     if (haithamR.currentState!.validate()) {
                //       ScaffoldMessenger.of(context).showSnackBar(
                //         const SnackBar(
                //           content: Text('Pr ocessing Data'),
                //         ),
                //       );
                //     }
                //     try {
                //       final user = _auth.signInWithEmailAndPassword(
                //           email: email, password: password);
                //       // ignore: unrelated_type_equality_checks
                //       if (user != email) {
                //         Navigator.pushNamed(context, ChatScreen.screenRoute);
                //       }
                //     } catch (e) {
                //       // ignore: avoid_print
                //       print(e);
                //     }
                //   },
                child: const Text('Continue'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
