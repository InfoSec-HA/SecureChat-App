import 'package:flutter/material.dart';

class ChatList extends StatefulWidget {
  const ChatList({super.key});

  @override
  State<ChatList> createState() => _ChatListState();
}

class _ChatListState extends State<ChatList> {
  List numbers = [777111777, 777222777, 777333777];
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(),
        body: Column(
          children: [
            for (int i = 0; i < 20; i++) ...[
              ListTile(
                leading: const Icon(Icons.face),
                title: const Text("777777777"),
                subtitle: const Row(
                  children: [
                    Icon(
                      Icons.check,
                      size: 20,
                    ),
                    Text("hi ")
                  ],
                ),
                trailing: const Text("12:00"),
                onTap: () {
                  showDialog(
                      context: context,
                      builder: (x) {
                        return const AlertDialog(
                          title: Text("مرحبا "),
                          content: Text("بكرة دوام"),
                        );
                      });
                },
                onLongPress: () {
                  showsnackpar(context);
                },
              ),
              const Divider(
                thickness: 1,
              )
            ]
          ],
        ),
      ),
    );
  }

  showsnackpar(BuildContext context) {
    return ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        action: SnackBarAction(label: "cancel", onPressed: () {}),
        backgroundColor: Color.fromARGB(255, 161, 55, 55),
        content: Text("hello")));
  }
}
