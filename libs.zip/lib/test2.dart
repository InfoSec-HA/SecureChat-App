import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class Chat extends StatefulWidget {
  const Chat({super.key});

  @override
  State<Chat> createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  List numbers = [
    7777777777,
    77777788888,
    77777777777,
    78525855555,
    88888888888,
    9999999999999
  ];
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        body: ListView(
          children: [
            for (int i = 0; i < numbers.length; i++) ...[
              ListTile(
                  onLongPress: () {
                    showsnackpar(context, "تمت العملية بنجاح");
                  },
                  onTap: () {
                    showDialog(
                        context: context,
                        builder: (context) {
                          return const AlertDialog(
                            alignment: Alignment.center,
                            title: Text("تمت العملية"),
                            actions: [Icon(Icons.delete), Text("yes")],
                            content: Text("مرحبا "),
                            actionsAlignment: MainAxisAlignment.end,
                          );
                        });
                  },
                  title: Text(numbers[i].toString()),
                  leading: const Icon(Icons.face),
                  trailing: const Text("3:45"),
                  subtitle: const Row(
                    children: [
                      Icon(
                        Icons.check,
                        size: 20,
                      ),
                      Text("hiii"),
                    ],
                  )),
              const Divider(
                thickness: 2,
              )
            ]
          ],
        ),
      ),
    );
  }

  showsnackpar(BuildContext context, msg) {
    return ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        action: SnackBarAction(label: "cancel", onPressed: () {}),
        backgroundColor: ui.Color.fromARGB(255, 238, 80, 80),
        content: Text(msg)));
  }
}
