import 'package:flutter/material.dart';

class constrct extends StatefulWidget {
  final phone;
 const constrct({super.key, this.phone});


  @override
  State<constrct> createState() => _constrctState();
}

class _constrctState extends State<constrct> {
  @override
  Widget build(BuildContext context) {
    return Text(widget.phone.toString());
  }
}