import 'package:flutter/material.dart';

showDialogMessage(BuildContext context) {
  
        return const AlertDialog(
          alignment: Alignment.center,
          title: Text("تمت العملية"),
          actions: [Icon(Icons.delete), Text("yes")],
          content: Text("مرحبا "),
          actionsAlignment: MainAxisAlignment.end,
        );
      
}
