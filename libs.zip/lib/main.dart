import 'package:flutter/material.dart';
import 'package:flutter_application_5/chatNumber.dart';
import 'package:flutter_application_5/listCard.dart';
import 'package:flutter_application_5/login.dart';
import 'package:flutter_application_5/signup.dart';
import 'package:intl/date_symbol_data_local.dart';

void main() {
  initializeDateFormatting('ar_SA', null); // تهيئة اللغة العربية
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      routes: {
        "/": (context) => const Home(),
        "login": (context) => const LogIn(),
        "signup": (context) => const SignUp(),
        "listCard": (context) => const ListCard()
      },
      
     
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {

    
    return DefaultTabController(
      initialIndex: 2,
      length: 3,
      child: Scaffold(
        endDrawer: Drawer( 
            child: ListView(
          children: [
            ListTile(
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushNamed("login");
              },
              leading: const Icon(Icons.login),
              title: const Text("login"),
            ),
            ListTile(
              onTap: () {
                Navigator.of(context).pushNamed("signup");
              },
              leading: const Icon(Icons.account_box),
              title: const Text("sigin"),
            ),
            ListTile(
              onTap: () {},
              leading: const Icon(Icons.home),
              title: const Text("main"),
            ),ListTile(
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushNamed("listCard");
              },
              leading: const Icon(Icons.login),
              title: const Text("ListCard"),
            ),
          ],
        )),
        appBar: AppBar(

          bottom: const TabBar(
              dividerColor: Color.fromARGB(255, 255, 255, 255),
              dividerHeight: 2,
              labelColor: Color.fromARGB(255, 255, 255, 255),
              tabs: [
                Tab(
                  icon: Icon(
                  Icons.chat,
                  color: Color.fromARGB(255, 255, 255, 255), 
                ),
                  
                     ),
                Tab(text: "الحالة" ),
                Tab(
                  text: "جهات الاتصال",
                 
                 
  
                 ),
                
              ], unselectedLabelColor: Color.fromARGB(255, 255, 255, 255), ),
              
          title:  Text(" App", style: TextStyle(color: const Color.fromARGB(255, 255, 255, 255)),)   ,
          

          leadingWidth: 110,
          backgroundColor:const Color.fromARGB(255, 238, 80, 80),
          leading: const Row(
            children: [
              Icon(Icons.more_vert , color: Color.fromARGB(255, 255, 255, 255),),
              
              SizedBox(
                width: 5,
              ),
              Icon(Icons.camera_alt_rounded, color: Color.fromARGB(255, 255, 255, 255), ),
              SizedBox(
                width: 5,
              ),
              Icon(Icons.search ,color: Color.fromARGB(255, 255, 255, 255), )
            ],
          ),
        ),
        body: const TabBarView(
            children: [chatNumber(), Text("الحالة"), Text("جهات الاتصال")]),
      ),
    );
  }
}




/**
 *   endDrawer: Drawer(
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: Column(
              children: [
                Container(
                  height: 100,
                ),
                ListTile(
                  leading: Icon(Icons.login),
                  title: Text("تسجيل الدخول"),
                  onTap: () {
                    Navigator.of(context).pushNamed("login");
                  },
                ),
              ],
            ),
          ),
        ),
 */