import 'package:flutter/material.dart';

class LogIn extends StatefulWidget {
  const LogIn({super.key});

  @override
  State<LogIn> createState() => _LogInState();
}

class _LogInState extends State<LogIn> {
  TextEditingController name = TextEditingController();

  GlobalKey<FormState> login = GlobalKey<FormState>();
  String? validName(String? val) {
    if (val!.trim().isEmpty) {
      return "الرجاء عدم ترك الحقل فارغا";
    }
    if (val.trim().length > 255 || val.trim().length < 3) {
      return "لاتستطيع كتابة اكثر من 255 او اقل من 3 احرف";
    }
    return null;
  }

  loginData() {
    var current = login.currentState;
    if (current!.validate()) {
      print("****************");
      print("form is validate");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(),
        body: Form(
            key: login,
            child: ListView(
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 200, right: 200),
                  child: TextFormField(
                      enableInteractiveSelection: false,
                      validator: validName,
                      controller: name,
                      // obscureText: true,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          icon: Icon(Icons.person),
                          // label: Text("الاسم"),
                          labelText: "اسم الشخص",
                          prefix: Text("967")),
                      textAlign: TextAlign.right),
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton.icon(
                      style: const ButtonStyle(
                          backgroundColor:
                              MaterialStatePropertyAll(Color.fromARGB(255, 238, 80, 80))),
                      label: const Text("save"),
                      onPressed: () {
                        loginData();
                      },
                      icon: const Icon(Icons.save),
                    ),
                  ],
                )
              ],
            )),
      ),
    );
  }
}
