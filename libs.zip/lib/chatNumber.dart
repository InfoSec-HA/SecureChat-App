import 'package:flutter/material.dart';
import 'package:flutter_application_5/constract.dart';

class chatNumber extends StatefulWidget {
  const chatNumber({super.key});

  @override
  State<chatNumber> createState() => _chatNumberState();
}

class _chatNumberState extends State<chatNumber> {
  List numbers = [
    777111222,
    777333444,
    777555666,
    777888999,
    777112233,
    777445566,
    777889900,
  ];
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        floatingActionButton: FloatingActionButton(onPressed: () {}),
        body: ListView(
          children: [
            for (int i = 0; i < numbers.length; i++) ...[
              ListTile(
                onLongPress: () {
                 Navigator.of(context).push(MaterialPageRoute(builder: (context){
return constrct(phone: numbers[i],);
                 }));
                },

                onTap: () {
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text("welcome"),
                          content: Text("welcome"),
                          actions: [
                            IconButton(onPressed: () {}, icon: Text("yes")),
                            IconButton(onPressed: () {}, icon: Text("no"))
                          ],
                        );
                      });
                },
                subtitle: Text("Hi"),
                trailing: Text("12:10"),
                leading: Icon(Icons.face),
                title: Text(numbers[i].toString()),
              ),
              Divider(
                thickness: 1,
              )
            ]
          ],
        ),
      ),
    );
  }

  showsnackpar(BuildContext context) {
    return ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        duration: Duration(),
        action: SnackBarAction(label: "cancel", onPressed: () {}),
        backgroundColor: Color.fromARGB(255, 238, 80, 80),
        content: Text("hello")));
  }
}
