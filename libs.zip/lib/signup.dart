import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:intl/date_symbol_data_local.dart'; // قم بإضافة هذا الاستيراد
class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  TextEditingController name = TextEditingController();
 TextEditingController pass = TextEditingController();
  TextEditingController date = TextEditingController();
 bool isvis=true;
 bool ischek=false;
 bool isSwich=false;
 int gender=1;

 
  //validators
  String? validName(String? val) {
    if (val!.trim().isEmpty) {
      return "الرجاء عدم ترك الحقل فارغا";
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    initializeDateFormatting('ar_SA', null);

    return Scaffold(
        appBar: AppBar(),
        body: ListView(
          children: [
            Form(
                child: Column(
              children: [
                TextFormField(
                  validator: validName,
                  decoration: const InputDecoration(
                    
                      prefix: Text("967"),
                      suffix: Text("YER"),
                      icon: Icon(Icons.person),
                      label: Text("user name"),
                      hintText: "please Enter your name",
                      iconColor: Color.fromARGB(255, 171, 75, 75),
                      border: OutlineInputBorder(),
                      filled: true,
                      fillColor: Color.fromARGB(255, 254, 154, 154)),
                  controller: name,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFormField(
                  obscureText: isvis,
                  
                  validator: validName,
                  decoration:  InputDecoration(
                    suffix: IconButton(onPressed: (){
                     setState(() {
                        isvis=!isvis;
                     });

                    }, icon: isvis?Icon(Icons.visibility):Icon(Icons.visibility_off)),
                      icon: Icon(Icons.lock),
                      label: Text("password"),
                      hintText: "please Enter your pass",
                      iconColor: Color.fromARGB(255, 171, 75, 75),
                      border: OutlineInputBorder(),
                      filled: true,
                      fillColor: Color.fromARGB(255, 254, 154, 154)),
                  controller: pass,
                ),
                   TextFormField(
                  validator: validName,
                  decoration:  InputDecoration(
                    
                  
                     suffixIcon: IconButton(onPressed:(){
                   showDatePicker(
                    initialDate: DateTime.now(),
                    helpText:"يرجى ادخال تاريخ " ,
                    cancelText: "الغاء",
                    confirmText: "موافق",
                    context: context, 
                      firstDate: DateTime.now(), 
                      lastDate: DateTime(2025)
                      



                      ).then((value){

                          if (value!=null) {
                            date.text=   DateFormat("yyyy/MM/dd","ar").format(value);

                          }
                      });


                     } , icon: Icon(Icons.calendar_month)),
                      icon: Icon(Icons.person),
                      label: Text("التاريخ"),
                      
                      iconColor: Color.fromARGB(255, 171, 75, 75),
                      border: OutlineInputBorder(),
                      filled: true,
                      fillColor: Color.fromARGB(255, 254, 154, 154)),
                  controller: date,
                ),
                Row(
                  mainAxisAlignment:MainAxisAlignment.center,
                  children: [
                   
                    Checkbox(
                      checkColor: Colors.blue,
                      activeColor: Colors.amber,

                      value: ischek, onChanged:(value){
                        setState(() {
                          ischek=value!;
                        });
                        print("888888888888888888");
                        print(ischek);
                    } ),
                     Text("تسديد"),
                  ],
                ),
              Row(children: [  
               Row(
                 children: [
                  Text("male"),
                   Radio(
                    activeColor:Colors.amber,
                    value: 1, groupValue: gender, onChanged: (value){
                     setState(() {
                        gender=value!;
                     });
                     print("************");
                     print(value);
                    }),
                 ],
               ),
                 Row(
                   children: [
                    const Text("femal"),
                     Radio(value:0, groupValue: gender, onChanged: (value){
                                    setState(() {
                        gender=value!;
                                    });
                      }),
                   ],
                 ),
                 Switch(value: isSwich, onChanged: (value){
                  setState(() {
                    isSwich=value;
                  });
      print("0000000000000000000000");
      print(isSwich);

                 })
                 ],)
              ],
            ))
          ],
        ));
  }
}
