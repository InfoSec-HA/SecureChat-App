import 'package:flutter/material.dart';
  getcard() {
    return Container(
      margin: const EdgeInsets.all(70),
      width: 350,
      height: 200,
      decoration: BoxDecoration(
        color: Color.fromARGB(255, 238, 80, 80),
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text("Eng",
            style: TextStyle(
                fontFamily: "DancingScript",
                color: Color.fromARGB(255, 238, 80, 80),
                fontSize: 30)),
        Text("Email: @gmail.com"),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.phone),
            Text("phone number : 7777777777"),
          ],
        )
      ]),
    );
  }
  /**
   * import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    const appBarColor = Color.fromARGB(255, 44, 158, 88); //
    const iconColors = Color(0xFFEBEBEB);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
            appBar: AppBar(
              title: const Text(
                style: TextStyle(color: iconColors),
                "واتساب",
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.right,
              ),
              backgroundColor: appBarColor,
              leadingWidth: 100,
              iconTheme: const IconThemeData(color: iconColors),
              actions: const [
                Icon(Icons.camera_alt_rounded),
                SizedBox(
                  width: 10,
                ),
                Icon(Icons.search),
                SizedBox(
                  width: 10,
                ),
                Icon(Icons.more_vert),
                SizedBox(
                  width: 10,
                ),
              ],
            ),
            body: Container(
              alignment: Alignment.center,
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  getcard(),
                  getImage(),
                ],
              ),
            )),
      ),
    );
  }

  getcard() {
    return Container(
      margin: const EdgeInsets.all(70),
      width: 350,
      height: 200,
      decoration: BoxDecoration(
        color: Colors.blueAccent,
        borderRadius: BorderRadius.circular(10),
      ),
      child:
          const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text("hothaifa monner alselwi",
            style: TextStyle(
                fontFamily: "DancingScript",
                color: Colors.white,
                fontSize: 30)),
        Text("Email: hothaifamoneer@gmail.com"),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.phone),
            Text("phone number : 7777777777"),
          ],
        )
      ]),
    );
  }

  getImage() {
    return Container(
      margin: const EdgeInsets.all(20),
      width: 100,
      height: 100,
      decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 2),
          image: const DecorationImage(
            image: AssetImage("images/santorini.jpg"),
            fit: BoxFit.fill,
          ),
          color: Colors.blue,
          borderRadius: BorderRadius.circular(100)),
    );
  }
}

   */